/**
 * Book
 */
public class Book {
    private
        String name;
        Author author;
        double price;
        
}